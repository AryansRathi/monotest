import { defineConfig, devices } from '@playwright/test';
import { testConfig } from './test.config';

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
    testDir: '.',

    /* Default timeout for each test. Deactivate if slowMo is set. */
    timeout: testConfig.slowMo ? 0 : testConfig.timeout,
    /* Default timeout for each expect. */
    expect: {
        timeout: testConfig.expectTimeout
    },
    /* Run tests in files in parallel */
    fullyParallel: true,
    /* Fail the build on CI if you accidentally left test.only in the source code. */
    forbidOnly: !!process.env.CI,
    /* Retry on CI only */
    retries: testConfig.retries,
    /* Opt out of parallel tests on CI. */
    workers: testConfig.workers,
    /* Reporter to use. See https://playwright.dev/docs/test-reporters */
    reporter: [
        ['list'],
        [
            'html',
            {
                outputFolder: 'test-results/playwright-report/',
                open: process.env.CI ? 'never' : 'on-failure'
            }
        ],
        ['json', { outputFile: 'test-results/results.json' }],
        [
            './reporters/a11y-reporter.ts',
            {
                outputDir: './test-results',
                reportFileName: 'a11y-report.html',
                projectKey: 'IX25 Accessibility Report'
            }
        ]
    ],
    outputDir: 'test-results/playwright-data/',

    /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */

    use: {
        /* Base URL to use in actions like `await page.goto('/')`. */
        baseURL: testConfig.baseURL,

        /* Timeouts for each action and navigation. */
        /* This prevents from waiting until the whole test times out because of a single action. */
        actionTimeout: testConfig.actionTimeout,
        navigationTimeout: testConfig.navigationTimeout,

        /* We are using a local deployment, so we need to ignore HTTPS errors. */
        ignoreHTTPSErrors: true,

        /* Make the locale configurable with an environment variable */
        locale: testConfig.locale,

        /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
        trace: 'retain-on-failure',
        video: 'retain-on-failure',

        launchOptions: {
            slowMo: testConfig.slowMo
        },

        contextOptions: {
            reducedMotion: 'reduce'
        }
    },

    /* Configure projects for major browsers */
    projects: [
        {
            name: 'setup',
            testMatch: /global\.setup\.ts/,
            teardown: testConfig.runTeardown ? 'teardown' : undefined
        },
        ...[
            {
                name: 'teardown',
                testMatch: /global\.teardown\.ts/
            }
        ].filter(() => testConfig.runTeardown),
        ...[
            {
                name: 'chromium',
                use: { ...devices['Desktop Chrome'] },
                dependencies: ['setup']
            },
            {
                name: 'firefox',
                use: { ...devices['Desktop Firefox'] },
                dependencies: ['setup']
            },
            {
                name: 'webkit',
                use: { ...devices['Desktop Safari'] },
                dependencies: ['setup']
            }
        ].filter(
            (project) => !testConfig.selectedBrowser || project.name === testConfig.selectedBrowser
        )

        /* Test against mobile viewports. */
        // {
        //   name: 'Mobile Chrome',
        //   use: { ...devices['Pixel 5'] },
        // },
        // {
        //   name: 'Mobile Safari',
        //   use: { ...devices['iPhone 12'] },
        // },

        /* Test against branded browsers. */
        // {
        //   name: 'Microsoft Edge',
        //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
        // },
        // {
        //   name: 'Google Chrome',
        //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
        // },
    ]
});
