import type { Locator } from '@playwright/test';
import { Studio } from '@pages/ix/studio';

export class FilesPage {
    readonly parent: Studio;
    readonly root: Locator;

    /** Folder rail (left sidebar) with Root and folder tree. */
    readonly sidebar: Locator;

    /** File manager toolbar (contains search and actions). */
    readonly toolbar: Locator;

    /** File manager table (main content). */
    readonly fileManagerTable: Locator;

    constructor(parent: Studio) {
        this.parent = parent;
        this.root = parent.root;

        this.sidebar = this.root.getByTestId('IS-FolderRail-Root');
        this.toolbar = this.root.getByTestId('IS-FileManagerToolbar');
        this.fileManagerTable = this.root.getByTestId('IS-FileManagerTable');
    }

    public async open() {
        await this.parent.navRail.filesButton.click();
    }
}
