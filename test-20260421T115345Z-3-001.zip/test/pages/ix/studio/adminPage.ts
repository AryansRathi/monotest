import type { Locator } from '@playwright/test';
import { LocaleSettingsTab } from './adminPage/localeSettingsTab';
import { TenantSettingsTab } from './adminPage/tenantSettingsTab';
import { UsersTab } from './adminPage/usersTab';
import { GroupsTab } from './adminPage/groupsTab';
import { RolesAndPermissionsTab } from './adminPage/rolesAndPermissionsTab';
import { CredentialsTab } from './adminPage/credentialsTab';
import { TaskManagementTab } from './adminPage/taskManagementTab';
import { AuthenticationTab } from './adminPage/authenticationTab';
import { Studio } from '@pages/ix/studio';
import { AdminPageSidebar } from './adminPage/sidebar';
import { ApiKeysTab } from './adminPage/apiKeysTab';
import { EmailSettingsTab } from './adminPage/emailSettingsTab';
import { EmailMessagesTab } from './adminPage/emailMessagesTab';
import { SolutionsTab } from './adminPage/solutionsTab';
import { SolutionDetailPage } from './adminPage/solutionDetailPage';
import { OAuth2ClientsTab } from './adminPage/oauth2ClientsTab';
import { CertificatesTab } from './adminPage/certificatesTab';

export class AdminPage {
    readonly parent: Studio;
    readonly root: Locator;

    readonly sidebar: AdminPageSidebar;

    readonly tenantSettingsTab: TenantSettingsTab;
    readonly localeSettingsTab: LocaleSettingsTab;
    readonly usersTab: UsersTab;
    readonly groupsTab: GroupsTab;
    readonly rolesAndPermissionsTab: RolesAndPermissionsTab;
    readonly credentialsTab: CredentialsTab;
    readonly apiKeysTab: ApiKeysTab;
    readonly oauth2ClientsTab: OAuth2ClientsTab;
    readonly taskManagementTab: TaskManagementTab;
    readonly authenticationTab: AuthenticationTab;
    readonly emailSettingsTab: EmailSettingsTab;
    readonly emailMessagesTab: EmailMessagesTab;
    readonly solutionsTab: SolutionsTab;
    readonly solutionDetailPage: SolutionDetailPage;
    readonly certificatesTab: CertificatesTab;

    constructor(parent: Studio) {
        this.parent = parent;
        this.root = parent.root.locator('main.v-main');

        this.sidebar = new AdminPageSidebar(this);

        this.tenantSettingsTab = new TenantSettingsTab(this);
        this.localeSettingsTab = new LocaleSettingsTab(this);
        this.usersTab = new UsersTab(this);
        this.groupsTab = new GroupsTab(this);
        this.rolesAndPermissionsTab = new RolesAndPermissionsTab(this);
        this.credentialsTab = new CredentialsTab(this);
        this.apiKeysTab = new ApiKeysTab(this);
        this.oauth2ClientsTab = new OAuth2ClientsTab(this);
        this.taskManagementTab = new TaskManagementTab(this);
        this.authenticationTab = new AuthenticationTab(this);
        this.emailSettingsTab = new EmailSettingsTab(this);
        this.emailMessagesTab = new EmailMessagesTab(this);
        this.solutionsTab = new SolutionsTab(this);
        this.solutionDetailPage = new SolutionDetailPage(this);
        this.certificatesTab = new CertificatesTab(this);
    }

    public async open() {
        await this.parent.navRail.adminButton.click();
    }
}
