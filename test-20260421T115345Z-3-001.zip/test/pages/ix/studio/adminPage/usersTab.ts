import { type Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { CreateUserModal } from './usersTab/createUserModal';
import { EditUserModal } from './usersTab/editUserModal';
import { ChangePasswordModal } from './usersTab/changePasswordModal';
import { DeleteConfirmModal } from './usersTab/deleteConfirmModal';
import { UserDetailsDrawer } from './usersTab/userDetailsDrawer';
import { AddGroupModal } from './usersTab/addGroupModal';
import { AddRoleModal } from './shared/addRoleModal';
import { TestUser } from '@factories/adminFactory';

export class UsersTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly createUserButton: Locator;
    readonly searchInput: Locator;
    readonly dataTable: Locator;
    readonly searchProgressBar: Locator;

    // Row-level locators
    readonly userRow: (username: string) => Locator;
    readonly actionsButton: (username: string) => Locator;
    readonly detailsButton: (username: string) => Locator;
    readonly statusChip: (username: string) => Locator;

    // Actions menu (rendered in a Vuetify overlay, scoped to the IxMenu root)
    readonly actionsMenuRoot: Locator;
    readonly actionsMenuEditItem: Locator;
    readonly actionsMenuChangePasswordItem: Locator;
    readonly actionsMenuDeleteItem: Locator;

    // Duplicate username/email dialogs (teleported to body by UserModal)
    readonly duplicateUsernameDialog: Locator;
    readonly duplicateUsernameCloseButton: Locator;
    readonly duplicateEmailDialog: Locator;
    readonly duplicateEmailCloseButton: Locator;

    // No-permission state (v-else branch when isAnyReadAllowed is false)
    readonly noPermissionMessage: Locator;

    // Modals and drawer
    readonly createUserModal: CreateUserModal;
    readonly editUserModal: EditUserModal;
    readonly changePasswordModal: ChangePasswordModal;
    readonly deleteConfirmModal: DeleteConfirmModal;
    readonly addGroupModal: AddGroupModal;
    readonly addRoleModal: AddRoleModal;
    readonly userDetailsDrawer: UserDetailsDrawer;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.createUserButton = this.root.getByTestId('IS-UsersView-Create-IxButton-root');
        this.searchInput = this.root
            .getByTestId('IS-UsersView-Search-IxInput-root')
            .getByRole('textbox');
        this.dataTable = this.root.getByTestId('IS-UsersView-DataTable-IxDataTable-root');
        this.searchProgressBar = this.dataTable.getByRole('progressbar').first();

        this.userRow = (username: string) =>
            this.dataTable
                .locator('tr')
                .filter({ has: this.parent.parent.page.locator('td', { hasText: username }) });

        this.actionsButton = (username: string) =>
            this.userRow(username).getByTestId('IS-UsersView-Actions-Button-IxIconButton-root');

        this.detailsButton = (username: string) =>
            this.userRow(username).getByTestId('IS-UsersView-User-IxIconButton-root');

        this.statusChip = (username: string) =>
            this.userRow(username).getByTestId('IS-UsersView-Status-IxChip-root');

        this.actionsMenuRoot = this.parent.parent.page.getByTestId(
            'IS-UsersView-Actions-IxMenu-root'
        );
        this.actionsMenuEditItem = this.actionsMenuRoot.getByTestId(
            'IS-UsersView-Actions-Edit-IxMenuListItem-root'
        );
        this.actionsMenuChangePasswordItem = this.actionsMenuRoot.getByTestId(
            'IS-UsersView-Actions-ChangePassword-IxMenuListItem-root'
        );
        this.actionsMenuDeleteItem = this.actionsMenuRoot.getByTestId(
            'IS-UsersView-Actions-Delete-IxMenuListItem-root'
        );

        // Duplicate dialogs are teleported to <body> by UserModal
        this.duplicateUsernameDialog = this.parent.parent.page.locator('div.v-overlay__content', {
            has: this.parent.parent.page.getByTestId(
                'IS-UserModal-DuplicateUsername-Close-IxButton-root'
            )
        });
        this.duplicateUsernameCloseButton = this.duplicateUsernameDialog.getByTestId(
            'IS-UserModal-DuplicateUsername-Close-IxButton-root'
        );
        this.duplicateEmailDialog = this.parent.parent.page.locator('div.v-overlay__content', {
            has: this.parent.parent.page.getByTestId(
                'IS-UserModal-DuplicateEmail-Close-IxButton-root'
            )
        });
        this.duplicateEmailCloseButton = this.duplicateEmailDialog.getByTestId(
            'IS-UserModal-DuplicateEmail-Close-IxButton-root'
        );

        this.noPermissionMessage = this.root.locator('.nopermission');

        this.createUserModal = new CreateUserModal(this);
        this.editUserModal = new EditUserModal(this);
        this.changePasswordModal = new ChangePasswordModal(this);
        this.deleteConfirmModal = new DeleteConfirmModal(this);
        this.addGroupModal = new AddGroupModal(this);
        this.addRoleModal = new AddRoleModal(parent);
        this.userDetailsDrawer = new UserDetailsDrawer(this);
    }

    public async open() {
        await this.parent.sidebar.usersTabButton.click();
        await this.userRow('admin').waitFor({ state: 'visible' });
        await this.searchProgressBar.waitFor({ state: 'hidden' });
    }

    /**
     * Reload the table by opening another tab and then opening this tab again.
     * This is necessary because after user crud actions, we have no
     * way to let playwright know when the table is updated.
     */
    public async reloadTable() {
        await this.parent.tenantSettingsTab.open();
        await this.open();
    }

    public async searchForUser(username: string) {
        await this.searchInput.fill(username);
    }

    public async createUser(user: TestUser) {
        await this.createUserButton.click();
        await this.createUserModal.usernameInput.fill(user.username);
        await this.createUserModal.firstNameInput.fill(user.firstName);
        await this.createUserModal.lastNameInput.fill(user.lastName);
        await this.createUserModal.emailInput.fill(user.email);
        await this.createUserModal.statusButton(user.status).click();
        await this.createUserModal.passwordInput.fill(user.password);
        await this.createUserModal.repeatPasswordInput.fill(user.password);

        if (user.groups.length > 0) {
            await this.createUserModal.addGroupButton.click();
            for (const group of user.groups) {
                await this.addGroupModal.groupItem(group).click();
            }
            await this.addGroupModal.submitButton.click();
        }

        if (user.roles.length > 0) {
            await this.createUserModal.addRoleButton.click();
            for (const role of user.roles) {
                await this.addRoleModal.roleItem(role).click();
            }
            await this.addRoleModal.submitButton.click();
        }

        await this.createUserModal.submitButton.click();
        await this.reloadTable();
    }

    public async editUserFields(
        username: string,
        updates: { firstName?: string; lastName?: string; email?: string }
    ) {
        await this.searchForUser(username);
        await this.actionsButton(username).click();
        await this.actionsMenuEditItem.click();

        if (updates.firstName !== undefined) {
            await this.editUserModal.firstNameInput.fill(updates.firstName);
        }
        if (updates.lastName !== undefined) {
            await this.editUserModal.lastNameInput.fill(updates.lastName);
        }
        if (updates.email !== undefined) {
            await this.editUserModal.emailInput.fill(updates.email);
        }

        await this.editUserModal.submitButton.click();
        await this.reloadTable();
    }

    public async addGroupToUser(username: string, groupName: string) {
        await this.searchForUser(username);
        await this.actionsButton(username).click();
        await this.actionsMenuEditItem.click();
        await this.editUserModal.addGroupButton.click();
        await this.addGroupModal.searchForGroup(groupName);
        await this.addGroupModal.groupItem(groupName).click();
        await this.addGroupModal.submitButton.click();
        await this.editUserModal.submitButton.click();
        await this.reloadTable();
    }

    public async addRoleToUser(username: string, roleName: string) {
        await this.searchForUser(username);
        await this.actionsButton(username).click();
        await this.actionsMenuEditItem.click();
        await this.editUserModal.addRoleButton.click();
        await this.addRoleModal.searchInput.fill(roleName);
        await this.addRoleModal.roleItem(roleName).click();
        await this.addRoleModal.submitButton.click();
        await this.editUserModal.submitButton.click();
        await this.reloadTable();
    }

    public async changeUserPassword(username: string, newPassword: string) {
        await this.searchForUser(username);
        await this.actionsButton(username).click();
        await this.actionsMenuChangePasswordItem.click();
        await this.changePasswordModal.passwordInput.fill(newPassword);
        await this.changePasswordModal.repeatPasswordInput.fill(newPassword);
        await this.changePasswordModal.submitButton.click();
        await this.reloadTable();
    }

    public async deleteUser(username: string) {
        await this.searchForUser(username);
        await this.actionsButton(username).click();
        await this.actionsMenuDeleteItem.click();
        await this.deleteConfirmModal.submitButton.click();
        await this.reloadTable();
    }

    public async openUserDetails(username: string) {
        await this.searchForUser(username);
        await this.detailsButton(username).click();
    }
}
