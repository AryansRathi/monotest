import type { Locator } from '@playwright/test';
import { CredentialsTab } from '../credentialsTab';

export class EditCredentialModal {
    readonly parent: CredentialsTab;
    readonly root: Locator;

    readonly nameInput: Locator;
    readonly pathInput: Locator;

    readonly saveButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: CredentialsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Edit VaultEntry'
        });

        this.nameInput = this.root
            .getByTestId('IS-CredentialsCreation-Title-IxInput-root')
            .getByRole('textbox');
        this.pathInput = this.root
            .getByTestId('IS-CredentialsCreation-Path-IxInput-root')
            .getByRole('textbox');

        this.saveButton = this.root.getByTestId('IS-CredentialsCreation-Save-IxButton-root');
        this.cancelButton = this.root.getByTestId('IS-CredentialsCreation-Cancel-IxButton-root');
    }
}
