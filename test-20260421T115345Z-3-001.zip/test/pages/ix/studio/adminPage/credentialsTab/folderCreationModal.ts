import type { Locator } from '@playwright/test';
import { CredentialsTab } from '../credentialsTab';

export class FolderCreationModal {
    readonly parent: CredentialsTab;
    readonly root: Locator;

    readonly basePathInput: Locator;
    readonly nameInput: Locator;
    readonly saveButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: CredentialsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId(
            'IS-CredentialsFolderCreation-IxModal-root'
        );

        this.basePathInput = this.root
            .getByTestId('IS-CredentialsFolderCreation-BasePath-IxInput-root')
            .getByRole('textbox');
        this.nameInput = this.root
            .getByTestId('IS-CredentialsFolderCreation-Name-IxInput-root')
            .getByRole('textbox');
        this.saveButton = this.root.getByTestId('IS-CredentialsFolderCreation-Save-IxButton-root');
        this.cancelButton = this.root.getByTestId(
            'IS-CredentialsFolderCreation-Cancel-IxButton-root'
        );
    }
}
