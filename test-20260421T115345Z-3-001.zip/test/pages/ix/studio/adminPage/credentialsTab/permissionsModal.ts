import type { Locator } from '@playwright/test';
import { CredentialsTab } from '../credentialsTab';

export class PermissionsModal {
    readonly parent: CredentialsTab;
    readonly root: Locator;

    readonly targetPathInput: Locator;
    readonly usersTabButton: Locator;
    readonly groupsTabButton: Locator;
    readonly rolesTabButton: Locator;
    readonly searchInput: Locator;
    readonly addButton: Locator;
    readonly inheritToggle: Locator;
    readonly saveButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: CredentialsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId('IS-CredentialsPermissions-IxModal-root');

        this.targetPathInput = this.root
            .getByTestId('IS-CredentialsPermissions-Target-IxInput-root')
            .getByRole('textbox');
        this.usersTabButton = this.root.getByTestId(
            'IS-CredentialsPermissions-Tab-Users-IxTabButton-root'
        );
        this.groupsTabButton = this.root.getByTestId(
            'IS-CredentialsPermissions-Tab-Groups-IxTabButton-root'
        );
        this.rolesTabButton = this.root.getByTestId(
            'IS-CredentialsPermissions-Tab-Groups-IxTabButton-root'
        );
        this.searchInput = this.root
            .getByTestId('IS-CredentialsPermissions-Search-IxInput-root')
            .getByRole('textbox');
        this.addButton = this.root.getByTestId('IS-CredentialsPermissions-Add-IxButton-root');
        this.inheritToggle = this.root.getByTestId(
            'IS-CredentialsPermissions-InheritToggle-IxToggle-root'
        );
        this.saveButton = this.root.getByTestId('IS-CredentialsPermissions-Save-IxButton-root');
        this.cancelButton = this.root.getByTestId('IS-CredentialsPermissions-Cancel-IxButton-root');
    }
}
