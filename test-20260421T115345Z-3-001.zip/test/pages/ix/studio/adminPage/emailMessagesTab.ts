import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';

export class EmailMessagesTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly refreshButton: Locator;
    readonly messagesTable: Locator;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.refreshButton = this.root.getByTestId('IS-EmailMessages-Refresh-IxIconButtonV2-root');
        this.messagesTable = this.root.getByTestId('IS-EmailMessages-Table-IxDataTable-root');
    }

    public async open() {
        await this.parent.sidebar.emailMessagesTabButton.click();
    }
}
