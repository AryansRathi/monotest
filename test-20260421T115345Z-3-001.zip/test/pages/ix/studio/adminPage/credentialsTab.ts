import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { CreateCredentialModal } from './credentialsTab/createCredentialModal';
import { EditCredentialModal } from './credentialsTab/editCredentialModal';
import { FolderCreationModal } from './credentialsTab/folderCreationModal';
import { PermissionsModal } from './credentialsTab/permissionsModal';
import type {
    TestTokenCredential,
    TestApiKeyCredential,
    TestUsernamePasswordCredential,
    TestClientIdSecretCredential
} from '@factories/adminFactory';

export class CredentialsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly createCredentialButton: Locator;
    readonly createFolderButton: Locator;
    readonly searchInput: Locator;

    readonly folderTree: Locator;
    readonly folderTreeItem: (folderName: string) => Locator;
    readonly folderTreeExpandButton: (folderName: string) => Locator;
    readonly folderTreeActionButton: (folderName: string) => Locator;
    readonly folderMenuRoot: (folderName: string) => Locator;
    readonly folderMenuPermissionsItem: (folderName: string) => Locator;
    readonly folderMenuDeleteItem: (folderName: string) => Locator;

    readonly emptyStateIcon: Locator;
    readonly emptyStateAddCredentialButton: Locator;

    readonly credentialsTable: Locator;
    readonly credentialRow: (credentialName: string) => Locator;
    readonly credentialStatusCell: (credentialName: string) => Locator;
    readonly credentialMenuButton: (credentialName: string) => Locator;
    readonly credentialMenuRoot: Locator;
    readonly credentialMenuEditItem: Locator;
    readonly credentialMenuDeleteItem: Locator;
    readonly credentialMenuActivateItem: Locator;
    readonly credentialMenuDeactivateItem: Locator;
    readonly credentialMenuPermissionsItem: Locator;

    readonly createCredentialModal: CreateCredentialModal;
    readonly editCredentialModal: EditCredentialModal;
    readonly folderCreationModal: FolderCreationModal;
    readonly permissionsModal: PermissionsModal;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.createCredentialButton = this.root.getByTestId(
            'IS-CredentialsView-AddCredential-IxButton-root'
        );
        this.createFolderButton = this.root.getByTestId(
            'IS-CredentialsView-AddFolder-IxButton-root'
        );
        this.searchInput = this.root
            .getByTestId('IS-CredentialsView-Search-IxInput-root')
            .getByRole('textbox');

        this.folderTree = this.root.getByTestId('IS-CredentialsView-Tree-IxTree-root');
        this.folderTreeItem = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.root.getByTestId(`IS-CredentialsView-Tree-IxTree-child-${suffix}`);
        };
        this.folderTreeExpandButton = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.root.getByTestId(`IS-CredentialsView-Tree-IxTree-expand-${suffix}`);
        };
        this.folderTreeActionButton = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.root.getByTestId(
                `IS-CredentialsView-Tree-Actions-${suffix}-IxIconButton-root`
            );
        };
        this.folderMenuRoot = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.parent.parent.page.getByTestId(
                `IS-CredentialsView-Tree-Actions-${suffix}-IxMenu-root`
            );
        };
        this.folderMenuPermissionsItem = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.parent.parent.page.getByTestId(
                `IS-CredentialsView-Tree-Actions-Permissions-${suffix}-IxMenuListItem-root`
            );
        };
        this.folderMenuDeleteItem = (folderName: string) => {
            const suffix = folderName === 'All Folders' ? '' : `/${folderName}`;
            return this.parent.parent.page.getByTestId(
                `IS-CredentialsView-Tree-Actions-Delete-${suffix}-IxMenuListItem-root`
            );
        };

        this.emptyStateIcon = this.root.getByTestId(
            'IS-CredentialsView-EmptyStateIcon-IxIcon-root'
        );
        this.emptyStateAddCredentialButton = this.root.getByTestId(
            'IS-CredentialsView-EmptyStateAddCredential-IxButton-root'
        );

        this.credentialsTable = this.root.getByTestId(
            'IS-CredentialsView-DataTable-IxDataTable-root'
        );
        this.credentialRow = (credentialName: string) =>
            this.credentialsTable.locator('tr').filter({
                has: this.parent.parent.page.locator('td div', {
                    hasText: credentialName
                })
            });
        this.credentialStatusCell = (credentialName: string) =>
            this.credentialRow(credentialName).locator('td').nth(5);
        this.credentialMenuButton = (credentialName: string) =>
            this.credentialRow(credentialName).getByTestId(
                'IS-CredentialsView-Actions-Button-IxIconButton-root'
            );
        this.credentialMenuRoot = this.parent.parent.page.getByTestId(
            'IS-CredentialsView-Actions-IxMenu-root'
        );
        this.credentialMenuEditItem = this.credentialMenuRoot.getByTestId(
            'IS-CredentialsView-Actions-Edit-IxMenuListItem-root'
        );
        this.credentialMenuDeleteItem = this.credentialMenuRoot.getByTestId(
            'IS-CredentialsView-Actions-Delete-IxMenuListItem-root'
        );
        this.credentialMenuActivateItem = this.credentialMenuRoot.getByTestId(
            'IS-CredentialsView-Actions-Activate-IxMenuListItem-root'
        );
        this.credentialMenuDeactivateItem = this.credentialMenuRoot.getByTestId(
            'IS-CredentialsView-Actions-Deactivate-IxMenuListItem-root'
        );
        this.credentialMenuPermissionsItem = this.credentialMenuRoot.getByTestId(
            'IS-CredentialsView-Actions-Permissions-IxMenuListItem-root'
        );

        this.createCredentialModal = new CreateCredentialModal(this);
        this.editCredentialModal = new EditCredentialModal(this);
        this.folderCreationModal = new FolderCreationModal(this);
        this.permissionsModal = new PermissionsModal(this);
    }

    public async open() {
        await this.parent.sidebar.credentialsTabButton.click();
    }

    /**
     * Reload the table by opening another tab and then opening this tab again.
     * This is necessary because after crud actions, we have no
     * way to let playwright know when the table is updated.
     */
    public async reloadTable() {
        await this.parent.tenantSettingsTab.open();
        await this.open();
    }

    public async deactivateCredential(credentialName: string) {
        await this.credentialMenuButton(credentialName).click();
        await this.credentialMenuDeactivateItem.click();
    }

    public async activateCredential(credentialName: string) {
        await this.credentialMenuButton(credentialName).click();
        await this.credentialMenuActivateItem.click();
    }

    public async createTokenCredential(credential: TestTokenCredential) {
        await this.createCredentialButton.click();
        await this.createCredentialModal.credentialTypeSelect.click();
        await this.createCredentialModal.credentialTypeTokenOption.click();
        await this.createCredentialModal.nameInput.fill(credential.name);
        await this.createCredentialModal.pathInput.fill(credential.path);
        await this.createCredentialModal.tokenInput.fill(credential.token);
        await this.createCredentialModal.saveButton.click();
        await this.reloadTable();
    }

    public async deleteCredential(credentialName: string) {
        await this.credentialMenuButton(credentialName).click();
        await this.credentialMenuDeleteItem.click();
    }

    public async renameCredential(credentialName: string, newName: string) {
        await this.credentialMenuButton(credentialName).click();
        await this.credentialMenuEditItem.click();
        await this.editCredentialModal.nameInput.fill(newName);
        await this.editCredentialModal.saveButton.click();
        await this.reloadTable();
    }

    public async createApiKeyCredential(credential: TestApiKeyCredential) {
        await this.createCredentialButton.click();
        await this.createCredentialModal.credentialTypeSelect.click();
        await this.createCredentialModal.credentialTypeApiKeyOption.click();
        await this.createCredentialModal.nameInput.fill(credential.name);
        await this.createCredentialModal.pathInput.fill(credential.path);
        await this.createCredentialModal.apiKeyInput.fill(credential.apiKey);
        await this.createCredentialModal.saveButton.click();
        await this.reloadTable();
    }

    public async createUsernamePasswordCredential(credential: TestUsernamePasswordCredential) {
        await this.createCredentialButton.click();
        await this.createCredentialModal.credentialTypeSelect.click();
        await this.createCredentialModal.credentialTypeUsernamePasswordOption.click();
        await this.createCredentialModal.nameInput.fill(credential.name);
        await this.createCredentialModal.pathInput.fill(credential.path);
        await this.createCredentialModal.usernameInput.fill(credential.username);
        await this.createCredentialModal.passwordInput.fill(credential.password);
        await this.createCredentialModal.saveButton.click();
        await this.reloadTable();
    }

    public async createClientIdSecretCredential(credential: TestClientIdSecretCredential) {
        await this.createCredentialButton.click();
        await this.createCredentialModal.credentialTypeSelect.click();
        await this.createCredentialModal.credentialTypeClientIDClientSecretOption.click();
        await this.createCredentialModal.nameInput.fill(credential.name);
        await this.createCredentialModal.pathInput.fill(credential.path);
        await this.createCredentialModal.clientIDInput.fill(credential.clientId);
        await this.createCredentialModal.clientSecretInput.fill(credential.clientSecret);
        await this.createCredentialModal.saveButton.click();
        await this.reloadTable();
    }

    public async createFolder(folderName: string) {
        await this.createFolderButton.click();
        await this.folderCreationModal.nameInput.fill(folderName);
        await this.folderCreationModal.saveButton.click();
    }

    public async deleteFolder(folderName: string) {
        await this.folderTreeActionButton(folderName).click();
        await this.folderMenuDeleteItem(folderName).click();
    }

    public async openFolderPermissions(folderName: string) {
        await this.folderTreeActionButton(folderName).click();
        await this.folderMenuPermissionsItem(folderName).click();
    }

    public async openCredentialPermissions(credentialName: string) {
        await this.credentialMenuButton(credentialName).click();
        await this.credentialMenuPermissionsItem.click();
    }

    public async selectFolder(folderName: string) {
        await this.folderTreeItem(folderName).click();
    }
}
