import { type Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { CreateGroupModal } from './groupsTab/createGroupModal';
import { EditGroupModal } from './groupsTab/editGroupModal';
import { DeleteGroupConfirmModal } from './groupsTab/deleteGroupConfirmModal';
import { AddRoleModal } from './shared/addRoleModal';
import { AddMemberModal } from './groupsTab/addMemberModal';
import { GroupDetailsPanel } from './groupsTab/groupDetailsPanel';
import { TestGroup } from '@factories/adminFactory';

export class GroupsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly createGroupButton: Locator;
    readonly searchInput: Locator;

    readonly dataTable: Locator;
    readonly dataTableRows: Locator;
    readonly searchProgressBar: Locator;

    // ─── Row-level locators ────────────────────────────────────────────────────
    /** Returns the table row that contains the given group name. */
    readonly groupRow: (name: string) => Locator;
    /** Returns the group-icon button (opens the details panel) for a specific row. */
    readonly detailsButton: (name: string) => Locator;
    /** Returns the actions (⋯) button for a specific row. */
    readonly actionsButton: (name: string) => Locator;
    /** Returns the "X Members" cell for a specific row. */
    readonly membersCell: (name: string) => Locator;
    /** Returns the "X Roles" cell for a specific row. */
    readonly rolesCell: (name: string) => Locator;

    // ─── Actions menu (rendered in a Vuetify overlay) ─────────────────────────
    readonly actionsMenuRoot: Locator;
    readonly actionsMenuEditItem: Locator;
    readonly actionsMenuDeleteItem: Locator;

    // ─── Modals & panel ───────────────────────────────────────────────────────
    readonly createGroupModal: CreateGroupModal;
    readonly editGroupModal: EditGroupModal;
    readonly deleteConfirmModal: DeleteGroupConfirmModal;
    readonly addRoleModal: AddRoleModal;
    readonly addMemberModal: AddMemberModal;
    readonly groupDetailsPanel: GroupDetailsPanel;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.createGroupButton = this.root.getByTestId('IS-GroupsView-Create-IxButton-root');
        this.searchInput = this.root
            .getByTestId('IS-GroupsView-Search-IxInput-root')
            .getByRole('textbox');

        this.dataTable = this.root
            .getByTestId('IS-GroupsView-DataTable-IxDataTable-root')
            .locator('tbody');
        this.dataTableRows = this.dataTable.locator('tr');
        this.searchProgressBar = this.dataTable.getByRole('progressbar').first();

        this.groupRow = (name: string) =>
            this.dataTable
                .getByTestId(/IS-GroupsView-DataTable-IxDataTable-row-\d+$/)
                .filter({ hasText: name });

        this.detailsButton = (name: string) =>
            this.groupRow(name).getByTestId('IS-GroupsView-Group-IxIconButton-root');

        this.actionsButton = (name: string) =>
            this.groupRow(name).getByTestId('IS-GroupsView-Actions-Button-IxIconButton-root');

        this.membersCell = (name: string) =>
            this.groupRow(name).getByTestId(
                /IS-GroupsView-DataTable-IxDataTable-row-\d+-cell-members/
            );

        this.rolesCell = (name: string) =>
            this.groupRow(name).getByTestId(
                /IS-GroupsView-DataTable-IxDataTable-row-\d+-cell-roles/
            );

        this.actionsMenuRoot = this.parent.parent.page.getByTestId(
            'IS-GroupsView-Actions-IxMenu-root'
        );
        this.actionsMenuEditItem = this.actionsMenuRoot.getByTestId(
            'IS-GroupsView-Actions-Edit-IxMenuListItem-root'
        );
        this.actionsMenuDeleteItem = this.actionsMenuRoot.getByTestId(
            'IS-GroupsView-Actions-Delete-IxMenuListItem-root'
        );

        this.createGroupModal = new CreateGroupModal(this);
        this.editGroupModal = new EditGroupModal(this);
        this.deleteConfirmModal = new DeleteGroupConfirmModal(this);
        this.addRoleModal = new AddRoleModal(this.parent);
        this.addMemberModal = new AddMemberModal(this);
        this.groupDetailsPanel = new GroupDetailsPanel(this);
    }

    // ─── Navigation ───────────────────────────────────────────────────────────

    public async open() {
        await this.parent.sidebar.groupsTabButton.click();
    }

    /**
     * Reload the table by opening another tab and then opening this tab again.
     * This is necessary because after crud actions, we have no
     * way to let playwright know when the table is updated.
     */
    public async reloadTable() {
        await this.parent.tenantSettingsTab.open();
        await this.open();
    }

    // ─── Search ───────────────────────────────────────────────────────────────

    public async searchForGroup(name: string) {
        // Wait for the list to be populated
        await this.searchProgressBar.waitFor({ state: 'hidden' });
        await this.searchInput.fill(name);
    }

    // ─── Create ───────────────────────────────────────────────────────────────

    public async createGroup(group: TestGroup) {
        await this.createGroupButton.click();
        await this.createGroupModal.nameInput.fill(group.name);
        await this.createGroupModal.descriptionInput.fill(group.description);

        if (group.roles.length > 0) {
            await this.createGroupModal.addRoleButton.click();
            for (const role of group.roles) {
                await this.addRoleModal.roleItem(role).click();
            }
            await this.addRoleModal.submitButton.click();
        }

        if (group.members.length > 0) {
            await this.createGroupModal.addMemberButton.click();
            for (const member of group.members) {
                await this.addMemberModal.memberItem(member).click();
            }
            await this.addMemberModal.submitButton.click();
        }

        await this.createGroupModal.submitButton.click();
        await this.reloadTable();
    }

    // ─── Edit ─────────────────────────────────────────────────────────────────

    /**
     * Opens the edit modal for the given group, applies field updates, and saves.
     * Only the provided fields are changed; omitted keys are left as-is.
     */
    public async editGroupFields(name: string, updates: { name?: string; description?: string }) {
        await this.searchForGroup(name);
        await this.actionsButton(name).click();
        await this.actionsMenuEditItem.click();

        if (updates.name !== undefined) {
            // await this.editGroupModal.nameInput.clear();
            await this.editGroupModal.nameInput.fill(updates.name);
        }
        if (updates.description !== undefined) {
            // await this.editGroupModal.descriptionInput.clear();
            await this.editGroupModal.descriptionInput.fill(updates.description);
        }

        await this.editGroupModal.submitButton.click();
        await this.reloadTable();
    }

    /**
     * Opens the edit modal for the given group and adds an existing user as a member.
     */
    public async addMemberToGroup(groupName: string, username: string) {
        await this.searchForGroup(groupName);
        await this.actionsButton(groupName).click();
        await this.actionsMenuEditItem.click();
        await this.editGroupModal.addMemberButton.click();
        await this.addMemberModal.memberItem(username).click();
        await this.addMemberModal.submitButton.click();
        await this.editGroupModal.submitButton.click();
        await this.editGroupModal.root.waitFor({ state: 'hidden' });
    }

    /**
     * Opens the edit modal for the given group and adds a role by name.
     */
    public async addRoleToGroup(groupName: string, roleName: string) {
        await this.searchForGroup(groupName);
        await this.actionsButton(groupName).click();
        await this.actionsMenuEditItem.click();
        await this.editGroupModal.addRoleButton.click();
        await this.addRoleModal.roleItem(roleName).click();
        await this.addRoleModal.submitButton.click();
        await this.editGroupModal.submitButton.click();
        await this.editGroupModal.root.waitFor({ state: 'hidden' });
    }

    // ─── Delete ───────────────────────────────────────────────────────────────

    public async deleteGroup(name: string) {
        await this.searchForGroup(name);
        await this.actionsButton(name).click();
        await this.actionsMenuDeleteItem.click();
        await this.deleteConfirmModal.submitButton.click();
    }

    // ─── Details panel ────────────────────────────────────────────────────────

    /**
     * Selects the group row by clicking the details icon button, which activates
     * the right-side GroupDetailsPanel showing the group's members and roles.
     */
    public async openGroupDetails(name: string) {
        await this.searchForGroup(name);
        await this.detailsButton(name).click();
    }
}
