import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';

export class EmailSettingsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly hostInput: Locator;
    readonly portInput: Locator;
    readonly saveButton: Locator;
    readonly resetButton: Locator;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.hostInput = this.root
            .getByTestId('IS-EmailSettings-Host-IxInput-root')
            .getByRole('textbox');
        this.portInput = this.root
            .getByTestId('IS-EmailSettings-Port-IxInput-root')
            .getByRole('spinbutton');
        this.saveButton = this.root.getByTestId('IS-EmailSettings-Save-IxButton-root');
        this.resetButton = this.root.getByTestId('IS-EmailSettings-Reset-IxButton-root');
    }

    public async open() {
        await this.parent.sidebar.emailSettingsTabButton.click();
    }
}
