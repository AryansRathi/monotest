import type { Locator } from '@playwright/test';
import { CertificatesTab } from '../certificatesTab';

export class ImportModal {
    readonly parent: CertificatesTab;
    readonly root: Locator;

    readonly nameInput: Locator;
    readonly aliasInput: Locator;
    readonly descriptionInput: Locator;
    readonly pemContentTextArea: Locator;
    readonly submitButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: CertificatesTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId('IS-TrustStoreImportModal-IxModal-root');

        this.nameInput = this.root
            .getByTestId('IS-TrustStoreImportModal-Name-IxInput-root')
            .getByRole('textbox');
        this.aliasInput = this.root
            .getByTestId('IS-TrustStoreImportModal-Alias-IxInput-root')
            .getByRole('textbox');
        this.descriptionInput = this.root
            .getByTestId('IS-TrustStoreImportModal-Description-IxInput-root')
            .getByRole('textbox');
        this.pemContentTextArea = this.root
            .getByTestId('IS-TrustStoreImportModal-PemContent-IxTextArea-root')
            .getByRole('textbox');
        this.submitButton = this.root.getByTestId(
            'IS-TrustStoreImportModal-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-TrustStoreImportModal-IxModal-cancel-IxButton-root'
        );
    }
}
