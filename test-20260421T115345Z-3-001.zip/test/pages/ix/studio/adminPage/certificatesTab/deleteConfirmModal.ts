import type { Locator } from '@playwright/test';
import { CertificatesTab } from '../certificatesTab';

export class DeleteConfirmModal {
    readonly parent: CertificatesTab;
    readonly root: Locator;

    readonly deleteButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: CertificatesTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId(
            'IS-TrustStoreView-DeleteConfirm-IxModal-root'
        );

        this.deleteButton = this.root.getByTestId(
            'IS-TrustStoreView-DeleteConfirm-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-TrustStoreView-DeleteConfirm-IxModal-cancel-IxButton-root'
        );
    }
}
