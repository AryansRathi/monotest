import { expect, type Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { CreateRoleModal } from './rolesAndPermissionsTab/createRoleModal';
import { ViewEditRoleModal } from './rolesAndPermissionsTab/viewEditRoleModal';
import { RoleDetailsDrawer } from './rolesAndPermissionsTab/roleDetailsDrawer';

export class RolesAndPermissionsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    /** Create button — currently hidden in the UI (v-if="false"), kept for future use. */
    readonly createRoleButton: Locator;
    readonly searchInput: Locator;

    readonly rolesTable: Locator;
    readonly searchProgressBar: Locator;
    readonly rolesTableRows: Locator;
    /** Returns the table row containing the given role name. */
    readonly roleRow: (roleName: string) => Locator;
    /** Shield icon button inside a row — opens the details drawer. */
    readonly roleDetailsButton: (roleName: string) => Locator;
    /** Three-dot actions button inside a row. */
    readonly roleMenuButton: (roleName: string) => Locator;
    readonly roleMenuRoot: Locator;
    readonly roleMenuEditItem: Locator;
    readonly roleMenuDeleteItem: Locator;

    /** "locked" readonly chip rendered inside a row when the role is readonly. */
    readonly readonlyChip: (roleName: string) => Locator;

    /** The scope-filter toggle bar (IxButtonToggle). */
    readonly scopeToggle: Locator;
    /** Returns an individual scope-filter button by its visible label. */
    readonly scopeToggleButton: (label: string) => Locator;

    readonly confirmDeleteRoleButton: Locator;

    readonly createRoleModal: CreateRoleModal;
    readonly viewEditRoleModal: ViewEditRoleModal;
    readonly roleDetailsDrawer: RoleDetailsDrawer;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.createRoleButton = this.root.getByTestId('IS-RolesView-Create-IxButton-root');
        this.searchInput = this.root
            .getByTestId('IS-RolesView-Search-IxInput-root')
            .getByRole('textbox');

        this.rolesTable = this.root
            .getByTestId('IS-RolesView-DataTable-IxDataTable-root')
            .locator('tbody');
        this.searchProgressBar = this.rolesTable.getByRole('progressbar').first();
        this.rolesTableRows = this.rolesTable.locator('tr');
        this.roleRow = (roleName: string) =>
            this.rolesTableRows.filter({
                has: this.parent.parent.page.locator('td', { hasText: roleName })
            });

        this.roleDetailsButton = (roleName: string) =>
            this.roleRow(roleName).getByTestId('IS-RolesView-Role-IxIconButton-root');

        this.roleMenuButton = (roleName: string) =>
            this.roleRow(roleName).getByTestId('IS-RolesView-Actions-Button-IxIconButton-root');

        this.readonlyChip = (roleName: string) =>
            this.roleRow(roleName).getByTestId('IS-RolesView-Readonly-IxChip-root');

        this.roleMenuRoot = this.parent.parent.page.getByTestId('IS-RolesView-Actions-IxMenu-root');
        this.roleMenuEditItem = this.roleMenuRoot.getByTestId(
            'IS-RolesView-Actions-Edit-IxMenuListItem-root'
        );
        this.roleMenuDeleteItem = this.roleMenuRoot.getByTestId(
            'IS-RolesView-Actions-Delete-IxMenuListItem-root'
        );

        this.scopeToggle = this.root.getByTestId('IS-RolesView-ScopeToggle-IxButtonToggle-root');
        this.scopeToggleButton = (label: string) =>
            this.scopeToggle.getByText(label, { exact: true });

        this.confirmDeleteRoleButton = this.parent.parent.page.getByTestId(
            'IS-RolesView-DeleteConfirm-IxModal-submit-IxButton-root'
        );

        this.createRoleModal = new CreateRoleModal(this);
        this.viewEditRoleModal = new ViewEditRoleModal(this);
        this.roleDetailsDrawer = new RoleDetailsDrawer(this);
    }

    public async open() {
        await this.parent.sidebar.rolesAndPermissionsTabButton.click();
        // Wait for the list to be populated
        await this.searchProgressBar.waitFor({ state: 'hidden' });
        await expect(this.rolesTableRows).not.toHaveCount(0);
        await expect(this.rolesTableRows).not.toHaveCount(1);
    }

    public async searchForRole(roleName: string) {
        // Wait for the list to be populated
        await this.searchProgressBar.waitFor({ state: 'hidden' });
        await this.searchInput.fill(roleName);
    }

    /**
     * Clicks the shield icon button in the matching row to open the details drawer.
     */
    public async openRoleDetails(roleName: string) {
        await this.searchForRole(roleName);
        await this.roleDetailsButton(roleName).click();
    }

    public async deleteRole(roleName: string) {
        await this.roleMenuButton(roleName).click();
        await this.roleMenuDeleteItem.click();
        await this.confirmDeleteRoleButton.click();
    }
}
