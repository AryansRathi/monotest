import type { Locator, Page } from '@playwright/test';

export class SolutionFormModal {
    readonly page: Page;
    readonly root: Locator;

    // Metadata step
    readonly nameInput: Locator;
    readonly technicalNameInput: Locator;
    readonly descriptionInput: Locator;
    readonly metadataCancelButton: Locator;
    readonly metadataNextButton: Locator;

    // Model selection steps — back/next are builder-scoped
    readonly appModelsBackButton: Locator;
    readonly appModelsNextButton: Locator;
    readonly processModelsBackButton: Locator;
    readonly processModelsNextButton: Locator;
    readonly dataModelsBackButton: Locator;
    readonly dataModelsNextButton: Locator;

    // Summary step
    readonly summaryBackButton: Locator;
    readonly summarySubmitButton: Locator;
    readonly summaryName: Locator;
    readonly summaryTechnicalName: Locator;
    readonly summaryDescription: Locator;

    constructor(page: Page) {
        this.page = page;
        this.root = page.getByTestId('IS-SolutionFormModal');

        // Metadata step inputs
        this.nameInput = this.root.getByTestId('IS-MetadataStep-Name').getByRole('textbox');
        this.technicalNameInput = this.root
            .getByTestId('IS-MetadataStep-TechnicalName')
            .getByRole('textbox');
        this.descriptionInput = this.root
            .getByTestId('IS-MetadataStep-Description')
            .getByRole('textbox');
        this.metadataCancelButton = this.root.getByTestId('IS-MetadataStep-Cancel');
        this.metadataNextButton = this.root.getByTestId('IS-MetadataStep-Next');

        // Model selection step navigation buttons
        this.appModelsBackButton = this.root.getByTestId('IS-APPModelsStep-Back');
        this.appModelsNextButton = this.root.getByTestId('IS-APPModelsStep-Next');
        this.processModelsBackButton = this.root.getByTestId('IS-PROCESSModelsStep-Back');
        this.processModelsNextButton = this.root.getByTestId('IS-PROCESSModelsStep-Next');
        this.dataModelsBackButton = this.root.getByTestId('IS-DATAModelsStep-Back');
        this.dataModelsNextButton = this.root.getByTestId('IS-DATAModelsStep-Next');

        // Summary step
        this.summaryBackButton = this.root.getByTestId('IS-SummaryStep-Back');
        this.summarySubmitButton = this.root.getByTestId('IS-SummaryStep-Submit');
        this.summaryName = this.root.getByTestId('IS-SummaryStep-Name');
        this.summaryTechnicalName = this.root.getByTestId('IS-SummaryStep-TechnicalName');
        this.summaryDescription = this.root.getByTestId('IS-SummaryStep-Description');
    }

    /** Returns the checkbox list container for a builder step ('APP' | 'PROCESS' | 'DATA'). */
    modelList(builder: 'APP' | 'PROCESS' | 'DATA'): Locator {
        return this.root.getByTestId(`IS-${builder}ModelsStep-List`);
    }

    /** Returns the search input inside a builder's model list. */
    modelSearch(builder: 'APP' | 'PROCESS' | 'DATA'): Locator {
        return this.root.getByTestId(`IS-ModelCheckboxList-Search-${builder}`).getByRole('textbox');
    }

    /** Returns the row element for a specific model in a builder's list. */
    modelRow(builder: 'APP' | 'PROCESS' | 'DATA', modelKey: string): Locator {
        return this.root.getByTestId(`IS-ModelCheckboxList-${builder}-${modelKey}`);
    }

    /** Returns the lock icon for an auto-added dependency model. */
    modelLockIcon(modelKey: string): Locator {
        return this.root.getByTestId(`IS-ModelCheckboxList-Lock-${modelKey}`);
    }

    /** Returns the "auto-added" chip for a dependency model. */
    modelAutoAddedChip(modelKey: string): Locator {
        return this.root.getByTestId(`IS-ModelCheckboxList-AutoAdded-${modelKey}`);
    }

    /** Returns the summary assignment row for a given model technical name. */
    summaryAssignment(modelTechnicalName: string): Locator {
        return this.root.getByTestId(`IS-SummaryStep-Assignment-${modelTechnicalName}`);
    }

    /** Returns the auto-added chip shown in the summary for a dependency model. */
    summaryAutoAddedChip(modelTechnicalName: string): Locator {
        return this.root.getByTestId(`IS-SummaryStep-AutoAdded-${modelTechnicalName}`);
    }

    /** Returns the credential entry shown in the summary. */
    summaryCredential(credentialName: string): Locator {
        return this.root.getByTestId(`IS-SummaryStep-Credential-${credentialName}`);
    }

    /** Fills the metadata step and advances to the next step. */
    async fillMetadata(name: string, description?: string): Promise<void> {
        await this.nameInput.fill(name);
        // Technical name is auto-generated on blur; trigger it explicitly
        await this.nameInput.blur();
        if (description) {
            await this.descriptionInput.fill(description);
        }
        await this.metadataNextButton.click();
    }

    /** Skips the current model selection step by clicking Next. */
    async skipModelStep(builder: 'APP' | 'PROCESS' | 'DATA'): Promise<void> {
        const nextBtn = {
            APP: this.appModelsNextButton,
            PROCESS: this.processModelsNextButton,
            DATA: this.dataModelsNextButton
        }[builder];
        await nextBtn.click();
    }

    /** Submits the wizard from the summary step. */
    async submit(): Promise<void> {
        await this.summarySubmitButton.click();
    }

    /** Cancels the wizard from the metadata step. */
    async cancel(): Promise<void> {
        await this.metadataCancelButton.click();
    }
}
