import type { Locator } from '@playwright/test';
import { UsersTab } from '../usersTab';

export class EditUserModal {
    readonly parent: UsersTab;
    readonly root: Locator;

    readonly firstNameInput: Locator;
    readonly lastNameInput: Locator;
    readonly emailInput: Locator;
    readonly addGroupButton: Locator;
    readonly addRoleButton: Locator;
    readonly statusInactiveButton: Locator;
    readonly statusActiveButton: Locator;

    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: UsersTab) {
        this.parent = parent;
        // Root anchored by submit button testid — unique to the UserModal component
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            has: parent.parent.parent.page.locator(
                '[data-testid="IS-UserModal-IxModal-submit-IxButton-root"]'
            )
        });

        // Use ^= (starts-with) to match dynamic testids that include the user's UUID
        this.firstNameInput = this.root
            .locator('[data-testid^="UserModal-Firstname-"]')
            .getByRole('textbox');
        this.lastNameInput = this.root
            .locator('[data-testid^="UserModal-Lastname-"]')
            .getByRole('textbox');
        this.emailInput = this.root
            .locator('[data-testid^="UserModal-Email-"]')
            .getByRole('textbox');
        this.addGroupButton = this.root.locator('[data-testid^="UserModal-AddGroup-"]');
        this.addRoleButton = this.root.locator('[data-testid^="UserModal-AddRole-"]');
        // IxButtonToggle renders each item with testid: `${dataTestid}-IxButtonToggle-btn-${value}`
        // In edit mode the UUID is in the middle, so match start AND end of the testid
        this.statusInactiveButton = this.root.locator(
            '[data-testid^="UserModal-Status-"][data-testid$="-IxButtonToggle-btn-INACTIVE"]'
        );
        this.statusActiveButton = this.root.locator(
            '[data-testid^="UserModal-Status-"][data-testid$="-IxButtonToggle-btn-ACTIVE"]'
        );

        this.cancelButton = this.root.getByTestId('IS-UserModal-IxModal-cancel-IxButton-root');
        this.submitButton = this.root.getByTestId('IS-UserModal-IxModal-submit-IxButton-root');
    }
}
