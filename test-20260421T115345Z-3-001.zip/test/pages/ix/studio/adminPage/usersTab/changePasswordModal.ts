import type { Locator } from '@playwright/test';
import { UsersTab } from '../usersTab';

export class ChangePasswordModal {
    readonly parent: UsersTab;
    readonly root: Locator;

    readonly passwordInput: Locator;
    readonly repeatPasswordInput: Locator;

    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: UsersTab) {
        this.parent = parent;
        // Root anchored by submit button testid — unique to the UserModal component
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            has: parent.parent.parent.page.locator(
                '[data-testid="IS-UserModal-IxModal-submit-IxButton-root"]'
            )
        });

        // Use ^= (starts-with) to match dynamic testids that include the user's UUID.
        // Note: "UserModal-Password-" does NOT match "UserModal-PasswordRepeat-" because
        // the character after "Password" differs ("-" vs "R").
        this.passwordInput = this.root
            .locator('[data-testid^="UserModal-Password-"]')
            .getByRole('textbox');
        this.repeatPasswordInput = this.root
            .locator('[data-testid^="UserModal-PasswordRepeat-"]')
            .getByRole('textbox');

        this.cancelButton = this.root.getByTestId('IS-UserModal-IxModal-cancel-IxButton-root');
        this.submitButton = this.root.getByTestId('IS-UserModal-IxModal-submit-IxButton-root');
    }
}
