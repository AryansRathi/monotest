import type { Locator } from '@playwright/test';
import { UsersTab } from '../usersTab';

export class DeleteConfirmModal {
    readonly parent: UsersTab;
    readonly root: Locator;

    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: UsersTab) {
        this.parent = parent;
        // Root anchored by the delete confirm modal's unique submit button testid
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            has: parent.parent.parent.page.locator(
                '[data-testid="IS-UsersView-DeleteConfirm-IxModal-submit-IxButton-root"]'
            )
        });

        this.cancelButton = this.root.getByTestId(
            'IS-UsersView-DeleteConfirm-IxModal-cancel-IxButton-root'
        );
        this.submitButton = this.root.getByTestId(
            'IS-UsersView-DeleteConfirm-IxModal-submit-IxButton-root'
        );
    }
}
