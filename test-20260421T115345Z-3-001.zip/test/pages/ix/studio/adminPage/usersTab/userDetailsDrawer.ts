import type { Locator } from '@playwright/test';
import { UsersTab } from '../usersTab';

export class UserDetailsDrawer {
    readonly parent: UsersTab;
    readonly root: Locator;

    readonly groupsTable: Locator;
    readonly rolesTable: Locator;

    readonly groupRow: (groupName: string) => Locator;
    readonly roleRow: (roleName: string) => Locator;

    constructor(parent: UsersTab) {
        this.parent = parent;
        // Use --temporary to distinguish from the nav rail navs which also render as nav.v-navigation-drawer
        this.root = parent.parent.parent.page.locator('nav.v-navigation-drawer--temporary');

        this.groupsTable = this.root.getByTestId(
            'IS-UserDetails-MemberOfDataTable-IxDataTable-root'
        );
        this.rolesTable = this.root.getByTestId('IS-UserDetails-RoleDataTable-IxDataTable-root');

        this.groupRow = (groupName) =>
            this.groupsTable.locator('tr').filter({ hasText: groupName });
        this.roleRow = (roleName) => this.rolesTable.locator('tr').filter({ hasText: roleName });
    }
}
