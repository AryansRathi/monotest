import type { Locator } from '@playwright/test';
import { ApiKeysTab } from '../apiKeysTab';

export class CreateApiKeyModal {
    readonly parent: ApiKeysTab;
    readonly root: Locator;

    readonly apiKeyNameInput: Locator;
    readonly apiKeyIDInput: Locator;

    readonly okayButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: ApiKeysTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Create API key'
        });

        this.apiKeyNameInput = this.root
            .getByTestId('IS-ApiKeyModal-Name-IxInput-root')
            .getByRole('textbox');

        this.apiKeyIDInput = this.root
            .getByTestId('IS-ApiKeyModal-Id-IxInput-root')
            .getByRole('textbox');

        this.okayButton = this.root.getByTestId('IS-ApiKeyModal-IxModal-submit-IxButton-root');
        this.cancelButton = this.root.getByTestId('IS-ApiKeyModal-IxModal-cancel-IxButton-root');
    }
}
