import type { Locator } from '@playwright/test';
import { ApiKeysTab } from '../apiKeysTab';

export class RegenerateApiKeyModal {
    readonly parent: ApiKeysTab;
    readonly root: Locator;

    readonly okayButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: ApiKeysTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Regenerate API key'
        });

        this.okayButton = this.root.getByTestId(
            'IS-ApiKeysView-RegenerateConfirm-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-ApiKeysView-RegenerateConfirm-IxModal-cancel-IxButton-root'
        );
    }
}
