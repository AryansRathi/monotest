import type { Locator } from '@playwright/test';
import { ApiKeysTab } from '../apiKeysTab';

export class DeleteApiKeyModal {
    readonly parent: ApiKeysTab;
    readonly root: Locator;

    readonly deleteButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: ApiKeysTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Delete API key'
        });

        this.deleteButton = this.root.getByTestId(
            'IS-ApiKeysView-DeleteConfirm-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-ApiKeysView-DeleteConfirm-IxModal-cancel-IxButton-root'
        );
    }
}
