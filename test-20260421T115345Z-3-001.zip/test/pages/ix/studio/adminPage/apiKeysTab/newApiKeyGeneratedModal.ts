import type { Locator } from '@playwright/test';
import { ApiKeysTab } from '../apiKeysTab';

export class NewApiKeyGeneratedModal {
    readonly parent: ApiKeysTab;
    readonly root: Locator;

    readonly apiKeyTextField: Locator;

    readonly okayButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: ApiKeysTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'New API Key Generated'
        });

        this.apiKeyTextField = this.root
            .getByTestId('IS-ApiKeysView-NewKey-IxInput-root')
            .getByRole('textbox');

        this.okayButton = this.root.getByTestId(
            'IS-ApiKeysView-NewKeyModal-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-ApiKeysView-NewKeyModal-IxModal-cancel-IxButton-root'
        );
    }

    public async getApiKey() {
        // explicitely wait here because inputValue() does not count
        // as an action for playwright and sometimes the modal with the
        // key would close faster than the inputValue() would be read
        const apiKey = await this.apiKeyTextField.inputValue();
        await this.apiKeyTextField.waitFor({ state: 'visible' });
        return apiKey;
    }
}
