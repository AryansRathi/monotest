import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { SolutionFormModal } from './solutionsTab/solutionFormModal';

export class SolutionDetailPage {
    readonly parent: AdminPage;
    readonly root: Locator;

    // Header actions
    readonly editButton: Locator;
    readonly deleteButton: Locator;
    readonly closeButton: Locator;

    // Left panel — component list
    readonly componentSearch: Locator;

    // Center panel — VueFlow graph
    readonly graph: Locator;

    // Right panel — metadata
    readonly technicalName: Locator;
    readonly description: Locator;

    // Delete confirmation modal
    readonly deleteConfirmModal: Locator;
    readonly deleteConfirmSubmitButton: Locator;

    // Edit modal
    readonly formModal: SolutionFormModal;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.editButton = this.root.getByTestId('IS-SolutionDetailView-Edit');
        this.deleteButton = this.root.getByTestId('IS-SolutionDetailView-Delete');
        this.closeButton = this.root.getByTestId('IS-SolutionDetailView-Close');

        this.componentSearch = this.root
            .getByTestId('IS-SolutionDetailView-ComponentSearch')
            .getByRole('textbox');

        this.graph = this.root.getByTestId('IS-SolutionDetailView-Graph');

        this.technicalName = this.root.getByTestId('IS-SolutionDetailView-TechnicalName');
        this.description = this.root.getByTestId('IS-SolutionDetailView-Description');

        this.deleteConfirmModal = parent.parent.page.getByTestId(
            'IS-SolutionDetailView-DeleteConfirm'
        );
        this.deleteConfirmSubmitButton = this.deleteConfirmModal.getByRole('button', {
            name: /delete/i
        });

        this.formModal = new SolutionFormModal(parent.parent.page);
    }

    /** Returns the component list item element for a node identified by its label. */
    componentItem(label: string): Locator {
        return this.root.getByTestId(`IS-SolutionDetailView-Component-${label}`);
    }

    /** Returns the credential entry shown in the right metadata panel. */
    credentialEntry(credentialName: string): Locator {
        return this.root.getByTestId(`IS-SolutionDetailView-Credential-${credentialName}`);
    }

    /** Returns the not-found error icon (shown when the solution id is invalid). */
    get notFoundIcon(): Locator {
        return this.root.getByTestId('IS-SolutionDetailView-NotFoundIcon');
    }

    /** Returns the back button shown on the not-found state. */
    get backButton(): Locator {
        return this.root.getByTestId('IS-SolutionDetailView-Back');
    }

    /** Opens the edit modal. */
    async openEdit(): Promise<void> {
        await this.editButton.click();
    }

    /** Opens the delete confirmation modal. */
    async openDelete(): Promise<void> {
        await this.deleteButton.click();
    }

    /** Confirms deletion. */
    async confirmDelete(): Promise<void> {
        await this.deleteConfirmSubmitButton.click();
    }

    /** Navigates back to the solutions list. */
    async close(): Promise<void> {
        await this.closeButton.click();
    }
}
