import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';

export class AdminPageSidebar {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly tenantSettingsTabButton: Locator;
    readonly localeSettingsTabButton: Locator;
    readonly usersTabButton: Locator;
    readonly groupsTabButton: Locator;
    readonly rolesAndPermissionsTabButton: Locator;
    readonly credentialsTabButton: Locator;
    readonly apiKeysTabButton: Locator;
    readonly oauth2ClientsTabButton: Locator;
    readonly taskManagementTabButton: Locator;
    readonly authenticationTabButton: Locator;
    readonly colorsTabButton: Locator;
    readonly emailSettingsTabButton: Locator;
    readonly emailMessagesTabButton: Locator;
    readonly solutionsTabButton: Locator;
    readonly certificatesTabButton: Locator;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root.getByTestId('IS-Admin-NavigationRail-IxNavigationRail-root');

        this.tenantSettingsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-tenantmgmt-IxListItem-root'
        );
        this.localeSettingsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-localesettings-IxListItem-root'
        );
        this.usersTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-usermgmt-IxListItem-root'
        );
        this.groupsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-groupmgmt-IxListItem-root'
        );
        this.rolesAndPermissionsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-rolemgmt-IxListItem-root'
        );
        this.credentialsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-credentialsmgmt-IxListItem-root'
        );
        this.apiKeysTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-apikeymgmnt-IxListItem-root'
        );
        this.oauth2ClientsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-oauth2clientsmgmt-IxListItem-root'
        );
        this.taskManagementTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-taskmgmt-IxListItem-root'
        );
        this.authenticationTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-IdentityMgmt-settings-IxListItem-root'
        );
        this.colorsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-ThemingBranding-colors-IxListItem-root'
        );
        this.emailSettingsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-Emails-emailsettings-IxListItem-root'
        );
        this.emailMessagesTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-Emails-emailmessages-IxListItem-root'
        );
        this.solutionsTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-Solutions-solutions-IxListItem-root'
        );
        this.certificatesTabButton = this.root.getByTestId(
            'IS-Admin-NavigationRail-Security-truststoremgmt-IxListItem-root'
        );
    }
}
