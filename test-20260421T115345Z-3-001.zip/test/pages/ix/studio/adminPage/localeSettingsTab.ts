import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';

export class LocaleSettingsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    /** Locale settings section (header/content). */
    readonly section: Locator;
    /** Multi-select for locales. */
    readonly localesSelect: Locator;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.section = this.root.getByTestId('IS-LocaleSettings');
        this.localesSelect = this.root.getByTestId('IS-LocaleSettings-Locales');
    }

    public async open() {
        await this.parent.sidebar.localeSettingsTabButton.click();
    }
}
