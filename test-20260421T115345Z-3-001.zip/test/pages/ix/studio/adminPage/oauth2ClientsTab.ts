import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { CreateOAuth2ClientModal } from './oauth2ClientsTab/createOAuth2ClientModal';
import { DeleteOAuth2ClientModal } from './oauth2ClientsTab/deleteOAuth2ClientModal';
import { RegenerateSecretModal } from './oauth2ClientsTab/regenerateSecretModal';
import { CredentialsModal } from './oauth2ClientsTab/credentialsModal';
import { TestOAuth2Client } from '../../../../factories/adminFactory';

export class OAuth2ClientsTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly createButton: Locator;
    readonly searchInput: Locator;
    readonly dataTable: Locator;

    readonly clientRow: (clientId: string) => Locator;
    readonly clientStatusChip: (clientId: string) => Locator;
    readonly clientMenuButton: (clientId: string) => Locator;

    readonly actionsMenu: Locator;
    readonly actionsEditItem: Locator;
    readonly actionsEnableItem: Locator;
    readonly actionsDisableItem: Locator;
    readonly actionsRegenerateItem: Locator;
    readonly actionsDeleteItem: Locator;

    readonly createModal: CreateOAuth2ClientModal;
    readonly deleteModal: DeleteOAuth2ClientModal;
    readonly regenerateModal: RegenerateSecretModal;
    readonly credentialsModal: CredentialsModal;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.createButton = this.root.getByTestId('IS-OAuth2ClientView-Create-IxButton-root');
        this.searchInput = this.root
            .getByTestId('IS-OAuth2ClientView-Search-IxInput-root')
            .getByRole('textbox');
        this.dataTable = this.root.getByTestId('IS-OAuth2ClientView-DataTable-IxDataTable-root');

        this.clientRow = (clientId: string) =>
            this.dataTable
                .locator('tr')
                .filter({ has: this.parent.parent.page.locator('td', { hasText: clientId }) });

        this.clientStatusChip = (clientId: string) =>
            this.clientRow(clientId).getByTestId('IS-OAuth2ClientView-Enabled-IxChip-root');

        this.clientMenuButton = (clientId: string) =>
            this.clientRow(clientId).getByTestId(
                'IS-OAuth2ClientView-Actions-Button-IxIconButton-root'
            );

        this.actionsMenu = this.parent.parent.page.getByTestId(
            'IS-OAuth2ClientView-Actions-IxMenu-root'
        );
        this.actionsEditItem = this.actionsMenu.getByTestId(
            'IS-OAuth2ClientView-Actions-Edit-IxMenuListItem-root'
        );
        this.actionsEnableItem = this.actionsMenu.getByTestId(
            'IS-OAuth2ClientView-Actions-Enable-IxMenuListItem-root'
        );
        this.actionsDisableItem = this.actionsMenu.getByTestId(
            'IS-OAuth2ClientView-Actions-Disable-IxMenuListItem-root'
        );
        this.actionsRegenerateItem = this.actionsMenu.getByTestId(
            'IS-OAuth2ClientView-Actions-Regenerate-IxMenuListItem-root'
        );
        this.actionsDeleteItem = this.actionsMenu.getByTestId(
            'IS-OAuth2ClientView-Actions-Delete-IxMenuListItem-root'
        );

        this.createModal = new CreateOAuth2ClientModal(this);
        this.deleteModal = new DeleteOAuth2ClientModal(this);
        this.regenerateModal = new RegenerateSecretModal(this);
        this.credentialsModal = new CredentialsModal(this);
    }

    public async open() {
        await this.parent.sidebar.oauth2ClientsTabButton.click();
    }

    public async createClient(
        client: TestOAuth2Client
    ): Promise<{ clientId: string; secret: string }> {
        await this.createButton.click();
        await this.createModal.clientIdSuffixInput.fill(client.clientIdSuffix);
        await this.createModal.nameInput.fill(client.name);
        if (client.description) {
            await this.createModal.descriptionInput.fill(client.description);
        }
        await this.createModal.submitButton.click();
        const clientId = await this.credentialsModal.getClientId();
        const secret = await this.credentialsModal.getSecret();
        await this.credentialsModal.okButton.click();
        return { clientId, secret };
    }

    public async deleteClient(clientId: string) {
        await this.clientMenuButton(clientId).click();
        await this.actionsDeleteItem.click();
        await this.deleteModal.deleteButton.click();
    }

    public async enableClient(clientId: string) {
        await this.clientMenuButton(clientId).click();
        await this.actionsEnableItem.click();
    }

    public async disableClient(clientId: string) {
        await this.clientMenuButton(clientId).click();
        await this.actionsDisableItem.click();
    }

    public async regenerateSecret(clientId: string): Promise<string> {
        await this.clientMenuButton(clientId).click();
        await this.actionsRegenerateItem.click();
        await this.regenerateModal.confirmButton.click();
        const secret = await this.credentialsModal.getSecret();
        await this.credentialsModal.okButton.click();
        return secret;
    }
}
