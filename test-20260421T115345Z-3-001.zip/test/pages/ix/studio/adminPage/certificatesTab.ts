import type { Locator } from '@playwright/test';
import { AdminPage } from '../adminPage';
import { ImportModal } from './certificatesTab/importModal';
import { DeleteConfirmModal } from './certificatesTab/deleteConfirmModal';
import type { TestCertificate } from '@factories/adminFactory';

export class CertificatesTab {
    readonly parent: AdminPage;
    readonly root: Locator;

    readonly importButton: Locator;
    readonly searchInput: Locator;

    readonly certificatesTable: Locator;
    readonly certificateRow: (certName: string) => Locator;
    readonly certificateStatusChip: (certName: string) => Locator;
    readonly actionsMenuButton: (certName: string) => Locator;
    readonly actionsMenuRoot: Locator;
    readonly actionsDetailsItem: Locator;
    readonly actionsEnableItem: Locator;
    readonly actionsDisableItem: Locator;
    readonly actionsDeleteItem: Locator;

    readonly detailsDrawer: Locator;
    readonly detailsCloseButton: Locator;
    readonly detailsStatusChip: Locator;

    readonly importModal: ImportModal;
    readonly deleteConfirmModal: DeleteConfirmModal;

    constructor(parent: AdminPage) {
        this.parent = parent;
        this.root = parent.root;

        this.importButton = this.root.getByTestId('IS-TrustStoreView-Import-IxButton-root');
        this.searchInput = this.root
            .getByTestId('IS-TrustStoreView-Search-IxInput-root')
            .getByRole('textbox');

        this.certificatesTable = this.root.getByTestId(
            'IS-TrustStoreView-DataTable-IxDataTable-root'
        );
        this.certificateRow = (certName: string) =>
            this.certificatesTable.locator('tr').filter({
                has: this.parent.parent.page.locator('td', { hasText: certName })
            });
        this.certificateStatusChip = (certName: string) =>
            this.certificateRow(certName).getByTestId('IS-TrustStoreView-Status-IxChip-root');
        this.actionsMenuButton = (certName: string) =>
            this.certificateRow(certName).getByTestId(
                'IS-TrustStoreView-Actions-Button-IxIconButton-root'
            );
        this.actionsMenuRoot = this.parent.parent.page.getByTestId(
            'IS-TrustStoreView-Actions-IxMenu-root'
        );
        this.actionsDetailsItem = this.actionsMenuRoot.getByTestId(
            'IS-TrustStoreView-Actions-Details-IxMenuListItem-root'
        );
        this.actionsEnableItem = this.actionsMenuRoot.getByTestId(
            'IS-TrustStoreView-Actions-Enable-IxMenuListItem-root'
        );
        this.actionsDisableItem = this.actionsMenuRoot.getByTestId(
            'IS-TrustStoreView-Actions-Disable-IxMenuListItem-root'
        );
        this.actionsDeleteItem = this.actionsMenuRoot.getByTestId(
            'IS-TrustStoreView-Actions-Delete-IxMenuListItem-root'
        );

        this.detailsDrawer = this.parent.parent.page.getByTestId('IS-TrustStoreView-DetailsDrawer');
        this.detailsCloseButton = this.detailsDrawer.getByTestId(
            'IS-TrustStoreView-DetailsClose-IxIconButton-root'
        );
        this.detailsStatusChip = this.detailsDrawer.getByTestId(
            'IS-TrustStoreView-DetailsStatus-IxChip-root'
        );

        this.importModal = new ImportModal(this);
        this.deleteConfirmModal = new DeleteConfirmModal(this);
    }

    public async open() {
        await this.parent.sidebar.certificatesTabButton.click();
    }

    public async importCertificate(cert: TestCertificate) {
        await this.importButton.click();
        await this.importModal.nameInput.fill(cert.name);
        await this.importModal.nameInput.blur();
        await this.importModal.aliasInput.fill(cert.alias);
        await this.importModal.pemContentTextArea.fill(cert.pemContent);
        await this.importModal.pemContentTextArea.blur();
        await this.importModal.submitButton.click();
    }

    public async deleteCertificate(certName: string) {
        await this.actionsMenuButton(certName).click();
        await this.actionsDeleteItem.click();
        await this.deleteConfirmModal.deleteButton.click();
    }

    public async enableCertificate(certName: string) {
        await this.actionsMenuButton(certName).click();
        await this.actionsEnableItem.click();
    }

    public async disableCertificate(certName: string) {
        await this.actionsMenuButton(certName).click();
        await this.actionsDisableItem.click();
    }

    public async openDetails(certName: string) {
        await this.actionsMenuButton(certName).click();
        await this.actionsDetailsItem.click();
    }
}
