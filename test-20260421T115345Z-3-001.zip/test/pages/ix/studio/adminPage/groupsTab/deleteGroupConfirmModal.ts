import type { Locator } from '@playwright/test';
import { GroupsTab } from '../groupsTab';

export class DeleteGroupConfirmModal {
    readonly parent: GroupsTab;
    readonly root: Locator;

    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: GroupsTab) {
        this.parent = parent;
        // Anchor by the submit button testid so the root is unambiguous even if
        // other overlays are present in the DOM at the same time.
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            has: parent.parent.parent.page.getByTestId(
                'IS-GroupsView-DeleteConfirm-IxModal-submit-IxButton-root'
            )
        });

        this.cancelButton = this.root.getByTestId(
            'IS-GroupsView-DeleteConfirm-IxModal-cancel-IxButton-root'
        );
        this.submitButton = this.root.getByTestId(
            'IS-GroupsView-DeleteConfirm-IxModal-submit-IxButton-root'
        );
    }
}
