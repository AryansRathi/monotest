import type { Locator } from '@playwright/test';
import { GroupsTab } from '../groupsTab';

export class EditGroupModal {
    readonly parent: GroupsTab;
    readonly root: Locator;

    readonly nameInput: Locator;
    readonly descriptionInput: Locator;
    readonly addMemberButton: Locator;
    readonly addRoleButton: Locator;

    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: GroupsTab) {
        this.parent = parent;
        // The edit modal reuses the same IS-GroupModal-* testids as CreateGroupModal.
        // Distinguish it from the create modal by its title text ("Edit Group" / "Edit group").
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Edit Group'
        });

        this.nameInput = this.root
            .getByTestId('IS-GroupModal-Name-IxInput-root')
            .getByRole('textbox');
        this.descriptionInput = this.root
            .getByTestId('IS-GroupModal-Description-IxTextArea-root')
            .getByRole('textbox');
        this.addMemberButton = this.root.getByTestId('IS-GroupModal-AddMember-IxButton-root');
        this.addRoleButton = this.root.getByTestId('IS-GroupModal-AddRole-IxButton-root');

        this.cancelButton = this.root.getByTestId('IS-GroupModal-IxModal-cancel-IxButton-root');
        this.submitButton = this.root.getByTestId('IS-GroupModal-IxModal-submit-IxButton-root');
    }
}
