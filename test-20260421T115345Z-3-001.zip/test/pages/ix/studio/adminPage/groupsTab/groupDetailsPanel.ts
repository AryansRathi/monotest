import type { Locator } from '@playwright/test';
import { GroupsTab } from '../groupsTab';

/**
 * The Group Details Panel is a right-side navigation drawer that slides in when
 * the user clicks the group icon button in the groups table row.
 * It displays the members and roles that belong to the selected group.
 */
export class GroupDetailsPanel {
    readonly parent: GroupsTab;
    readonly root: Locator;

    readonly membersTable: Locator;
    readonly rolesTable: Locator;

    /** Returns the table row for a specific member username. */
    readonly memberRow: (username: string) => Locator;
    /** Returns the table row for a specific role name. */
    readonly roleRow: (roleName: string) => Locator;

    constructor(parent: GroupsTab) {
        this.parent = parent;
        // The panel renders as a right-side navigation drawer (v-navigation-drawer--right).
        // It is always present in the DOM; it becomes active (visible) when a group row's
        // details button is clicked.
        this.root = parent.parent.parent.page.locator('nav.v-navigation-drawer--right');

        this.membersTable = this.root.getByTestId(
            'IS-GroupDetails-MemberOfDataTable-IxDataTable-root'
        );
        this.rolesTable = this.root.getByTestId('IS-GroupDetails-RoleDataTable-IxDataTable-root');

        this.memberRow = (username: string) =>
            this.membersTable.locator('tr').filter({ hasText: username });

        this.roleRow = (roleName: string) =>
            this.rolesTable.locator('tr').filter({ hasText: roleName });
    }
}
