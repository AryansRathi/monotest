import type { Locator } from '@playwright/test';
import { RolesAndPermissionsTab } from '../rolesAndPermissionsTab';

/**
 * Page object for the RoleModal when opened in view or edit mode (via the actions menu).
 * The same RoleModal component is used for both view-only (readonly roles) and
 * editable roles. In view-only mode the form fields and submit button are disabled.
 */
export class ViewEditRoleModal {
    readonly parent: RolesAndPermissionsTab;
    readonly root: Locator;

    readonly nameInput: Locator;
    readonly descriptionInput: Locator;
    readonly cancelButton: Locator;
    readonly submitButton: Locator;

    constructor(parent: RolesAndPermissionsTab) {
        this.parent = parent;
        // Anchor the root by the submit button so the locator is unambiguous.
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            has: parent.parent.parent.page.getByTestId('IS-RoleModal-IxModal-submit-IxButton-root')
        });

        this.nameInput = this.root
            .getByTestId('IS-RoleModal-Name-IxInput-root')
            .getByRole('textbox');
        this.descriptionInput = this.root
            .getByTestId('IS-RoleModal-Description-IxTextArea-root')
            .getByRole('textbox');

        this.cancelButton = this.root.getByTestId('IS-RoleModal-IxModal-cancel-IxButton-root');
        this.submitButton = this.root.getByTestId('IS-RoleModal-IxModal-submit-IxButton-root');
    }
}
