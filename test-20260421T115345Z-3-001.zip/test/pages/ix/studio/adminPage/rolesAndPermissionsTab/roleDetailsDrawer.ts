import type { Locator } from '@playwright/test';
import { RolesAndPermissionsTab } from '../rolesAndPermissionsTab';

/**
 * The Role Details Drawer is a right-side navigation drawer that slides in when
 * the user clicks the shield icon button in a roles table row.
 * It displays the permissions and users that belong to the selected role.
 */
export class RoleDetailsDrawer {
    readonly parent: RolesAndPermissionsTab;
    readonly root: Locator;

    readonly permissionsTable: Locator;
    readonly usersTable: Locator;

    constructor(parent: RolesAndPermissionsTab) {
        this.parent = parent;
        // The drawer renders as a right-side navigation drawer (v-navigation-drawer--right).
        this.root = parent.parent.parent.page.locator('nav.v-navigation-drawer--right');

        this.permissionsTable = this.root.getByTestId(
            'IS-RoleDetails-PermissionDataTable-IxDataTable-root'
        );
        this.usersTable = this.root.getByTestId('IS-RoleDetails-UserDataTable-IxDataTable-root');
    }

    /**
     * Closes the drawer by clicking the Vuetify scrim overlay.
     * Required before interacting with table rows while the drawer is open,
     * as the scrim intercepts pointer events over the table.
     */
    public async close() {
        await this.parent.parent.parent.page.locator('.v-navigation-drawer__scrim').click();
    }
}
