import type { Locator } from '@playwright/test';
import { OAuth2ClientsTab } from '../oauth2ClientsTab';

export class CreateOAuth2ClientModal {
    readonly parent: OAuth2ClientsTab;
    readonly root: Locator;

    readonly clientIdSuffixInput: Locator;
    readonly nameInput: Locator;
    readonly descriptionInput: Locator;

    readonly submitButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: OAuth2ClientsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.locator('div.v-overlay__content', {
            hasText: 'Create OAuth2 client'
        });

        this.clientIdSuffixInput = this.root
            .getByTestId('IS-OAuth2ClientModal-ClientIdSuffix-IxInput-root')
            .getByRole('textbox');
        this.nameInput = this.root
            .getByTestId('IS-OAuth2ClientModal-Name-IxInput-root')
            .getByRole('textbox');
        this.descriptionInput = this.root
            .getByTestId('IS-OAuth2ClientModal-Description-IxTextArea-root')
            .getByRole('textbox');

        this.submitButton = this.root.getByTestId(
            'IS-OAuth2ClientModal-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-OAuth2ClientModal-IxModal-cancel-IxButton-root'
        );
    }
}
