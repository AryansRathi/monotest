import type { Locator } from '@playwright/test';
import { OAuth2ClientsTab } from '../oauth2ClientsTab';

export class CredentialsModal {
    readonly parent: OAuth2ClientsTab;
    readonly root: Locator;

    readonly clientIdInput: Locator;
    readonly secretInput: Locator;

    readonly okButton: Locator;

    constructor(parent: OAuth2ClientsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId(
            'IS-OAuth2ClientView-CredentialsModal-IxModal-root'
        );

        this.clientIdInput = this.root
            .getByTestId('IS-OAuth2ClientView-ClientId-IxInput-root')
            .getByRole('textbox');

        this.secretInput = this.root
            .getByTestId('IS-OAuth2ClientView-Secret-IxInput-root')
            .getByRole('textbox');

        this.okButton = this.root.getByTestId(
            'IS-OAuth2ClientView-CredentialsModal-IxModal-submit-IxButton-root'
        );
    }

    public async getClientId(): Promise<string> {
        await this.clientIdInput.waitFor({ state: 'visible' });
        return this.clientIdInput.inputValue();
    }

    public async getSecret(): Promise<string> {
        await this.secretInput.waitFor({ state: 'visible' });
        return this.secretInput.inputValue();
    }
}
