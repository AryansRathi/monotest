import type { Locator } from '@playwright/test';
import { OAuth2ClientsTab } from '../oauth2ClientsTab';

export class RegenerateSecretModal {
    readonly parent: OAuth2ClientsTab;
    readonly root: Locator;

    readonly confirmButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: OAuth2ClientsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId(
            'IS-OAuth2ClientView-RegenerateConfirm-IxModal-root'
        );

        this.confirmButton = this.root.getByTestId(
            'IS-OAuth2ClientView-RegenerateConfirm-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-OAuth2ClientView-RegenerateConfirm-IxModal-cancel-IxButton-root'
        );
    }
}
