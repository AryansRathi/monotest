import type { Locator } from '@playwright/test';
import { OAuth2ClientsTab } from '../oauth2ClientsTab';

export class DeleteOAuth2ClientModal {
    readonly parent: OAuth2ClientsTab;
    readonly root: Locator;

    readonly deleteButton: Locator;
    readonly cancelButton: Locator;

    constructor(parent: OAuth2ClientsTab) {
        this.parent = parent;
        this.root = parent.parent.parent.page.getByTestId(
            'IS-OAuth2ClientView-DeleteConfirm-IxModal-root'
        );

        this.deleteButton = this.root.getByTestId(
            'IS-OAuth2ClientView-DeleteConfirm-IxModal-submit-IxButton-root'
        );
        this.cancelButton = this.root.getByTestId(
            'IS-OAuth2ClientView-DeleteConfirm-IxModal-cancel-IxButton-root'
        );
    }
}
