import { Locator, Page } from '@playwright/test';

export class Portal {
    readonly page: Page;
    readonly root: Locator;

    readonly stageSwitcherButton: Locator;
    readonly draftStageButton: Locator;
    readonly testStageButton: Locator;
    readonly prodStageButton: Locator;

    readonly searchInput: Locator;

    readonly appModelCard: (name: string) => Locator;

    constructor(page: Page) {
        this.page = page;
        this.root = page.locator('#app');

        this.stageSwitcherButton = this.root.locator('div.stage-switcher button');
        this.draftStageButton = this.page.getByRole('button', { name: 'Draft' });
        this.testStageButton = this.page.getByRole('button', { name: 'Test' });
        this.prodStageButton = this.page.getByRole('button', { name: 'Production' });

        this.searchInput = this.root.getByRole('textbox', { name: 'Search' });

        this.appModelCard = (name: string) => {
            return this.root.locator('div.overview-grid div.v-card', { hasText: name });
        };
    }

    public async open() {
        await this.page.goto('/portal');
    }
}
